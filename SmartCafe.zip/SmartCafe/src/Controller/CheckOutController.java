
package Controller;

import Model.Connections;
import Model.Makanan;
import Model.MenuModel;
import Model.Minuman;
import View.CheckOutMenu;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class CheckOutController {
   CheckOutMenu viewCheck;
   ArrayList<MenuModel> listMenu ;
   Connections db = new Connections();

    public CheckOutController(CheckOutMenu viewCheck, ArrayList<MenuModel> listMenu) {
        this.viewCheck = viewCheck;
        this.listMenu = listMenu;
        this.viewCheck.buttonSubmit(new BtnSubmit());
    }
    
    class BtnSubmit implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            if (viewCheck.getNama().equals("") && viewCheck.getNoMeja().equals("")) {
                JOptionPane.showMessageDialog(null, "Anda belum mengisi data dengan benar, Mohon Masukkan data dengan benar!");
            } else {
                //button ini di gunakan untuk mengirimkan ke database (menggunakan controller)
                int result = JOptionPane.showConfirmDialog(viewCheck, "Are you sure you want to checkout?", "Confirm Checkout", JOptionPane.YES_NO_OPTION);
                if (result == JOptionPane.YES_OPTION) {
                    // Process payment and close dialog
                    try{
                        Connection con = db.getConnection();
                        Statement stat = con.createStatement();
                        String sql;
                        String nama = viewCheck.getNama();
                        String noMeja = viewCheck.getNoMeja();
                        String catatan = viewCheck.getCatatan();
                        String jenis = viewCheck.getJenisPesanan();
                        int total = listMenu.size();
                        double harga = 0;
                        for(MenuModel m : listMenu){
                            harga = harga + m.getHarga() + m.getQty();
                            sql = "INSERT INTO DetailPesanan (Nama_Menu, Qty, Harga) VALUES ("+m.getNama()+", "+m.getQty()+", "+m.getHarga()+")";
                        }
//                        
//                        for(Minuman m : listMinuman){
//                            harga = harga + m.getHarga() + m.getQty();
//                            sql = "INSERT INTO DetailPesanan (Nama_Menu, Qty, Harga) VALUES ("+m.getNama()+", "+m.getQty()+", "+m.getHarga()+")";
//                        }
                        sql = "INSERT INTO Pesanan (Nama_Pesanan, Nomor_Meja, Catatan, Jenis_Pesanan, Total_Item, Total) VALUES ("+nama+", "+noMeja+", "+catatan+", "+jenis+", "+total+", "+harga+")";
                        stat.execute(sql);
                        
                    } catch (Exception ex){
                        
                    }
                    
                    viewCheck.dispose();
                }

            }
        }
        
    }
    
    
}
