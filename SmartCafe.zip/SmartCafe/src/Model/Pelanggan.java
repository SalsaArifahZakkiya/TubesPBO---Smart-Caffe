
package Model;

public class Pelanggan{
    private String NoMeja;
    private String Nama;

    public String getNama() {
        return Nama;
    }

    public void setNama(String Nama) {
        this.Nama = Nama;
    }
    
    
    public Pelanggan(String NoMeja) {
        this.NoMeja = NoMeja;
    }

    public String getNoMeja() {
        return NoMeja;
    }

    public void setNoMeja(String NoMeja) {
        this.NoMeja = NoMeja;
    }
   
     
    
}
