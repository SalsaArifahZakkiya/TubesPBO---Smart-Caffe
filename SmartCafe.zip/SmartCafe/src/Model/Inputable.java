
package Model;

import Controller.MenuController;
import View.MenuView;

public interface Inputable {
   public abstract void inputDataMenu(MenuView mv, int x); 
}
