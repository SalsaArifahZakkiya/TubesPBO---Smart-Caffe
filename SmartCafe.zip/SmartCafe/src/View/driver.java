/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import Controller.CheckOutController;
import Controller.MakananController;
import Controller.MenuController;
import Controller.MinumanController;

/**
 *
 * @author dadannks
 */
public class driver {
    public static void main(String[] args){
        MenuView m1 = new MenuView();
        MenuController mn = new MenuController(m1);
        MakananController mc = new MakananController(m1, mn);
        MinumanController mi = new MinumanController(m1, mn);
        
        m1.setVisible(true);
    }
    
}
